Upload index.html and the images folder together to GitHub. Keep the images folder next to index.html.
